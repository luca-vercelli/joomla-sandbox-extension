<?php
/**
 * @author Luca Vercelli
 * @date: 21.07.2014
 * @license    GNU General Public License version 2 or later
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla controller library
jimport('joomla.application.component.controller');
 
/**
 * Component Controller
 */
class SandboxController extends JControllerLegacy
{

//warning. if ./sandbox is a link that points to . then 
//whole joomla site will be destroyed!!!

    public function create() {
        comSandboxHelper::performDatabaseCopy();
        comSandboxHelper::performFileCopy();
        comSandboxHelper::updateConfigPHP();
        
        JFactory::getApplication()->enqueueMessage(JText::_('Done.'));
        JFactory::getApplication()->enqueueMessage("<A href=\"". JURI::root() .SANDBOX_FOLDER. "\" target=\"_blank\">".JText::_("Access sandbox site")."</A>");
        
        JControllerLegacy::display();
    }
    
    public function remove() {
        comSandboxHelper::dropSandboxTables();
        if (file_exists(SANDBOX_FULL_PATH)) {
            comSandboxHelper::recurseDelete(SANDBOX_FULL_PATH, true);
        }
        
        JFactory::getApplication()->enqueueMessage(JText::_('Done.'));
        
        JControllerLegacy::display();
    }
}

